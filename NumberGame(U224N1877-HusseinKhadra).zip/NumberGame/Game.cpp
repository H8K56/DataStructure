#include "./Move.h"
using namespace std;

int main()
{
    Move game;

    game.GamePlay();

    return 0;
}